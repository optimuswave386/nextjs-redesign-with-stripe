import Image from 'next/image'
import type { CSSProperties } from "react";
import type { Product } from "@/lib/products";

async function DynamicImage({ dbFilename, alt }: { dbFilename: string, alt: string }) {
  try {
    const { default: imageAsset } = await import(`@/assets/images/${dbFilename}`);    
    return (
      <Image 
        src={imageAsset} 
        alt={alt} 
        fill 
        className="object-fit-sm-contain object-fit-md-cover" 
        sizes="(max-width: 768px) 100vw, 33vw" 
      />
    );
  } catch (error) {
    return <div className="art fallback-placeholder">Image not found</div>;
  }
}

// Placeholder artwork built from the active theme, so products always match the site colours.
export function ProductArt({ index, kind, imgUrl }: { index: number; kind: Product["kind"], imgUrl: Product["imgUrl"] }) {
  const style = { "--a": `${(index * 67) % 360}deg` } as CSSProperties;
  return ( 
    <>
      <div className="art" data-kind={kind} style={style} aria-hidden="true">
        <DynamicImage dbFilename={imgUrl} alt={kind} />
      </div>
    </>
    );
}
